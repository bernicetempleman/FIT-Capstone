/*
Course Number & Section:    CIS5989-W01
Assignment Designation:     Capstone Project
Name:                       Bernice Templeman

merge sort code is based on code from: https://courses.cs.washington.edu/courses/cse373/13wi/lectures/03-13/ArraySum.java
stdRandom is based on code from: http://introcs.cs.princeton.edu/java/stdlib/javadoc/StdRandom.html
 */
package BTMS;

// CSE 373, Winter 2013, Marty Stepp

import BTMS.BTMS;

// A Summer is a task that can be run in a thread that computes the sum
// of a given range of numbers in a large array.

public class Summer implements Runnable {
	private int[] a;
	private int min, max;
	private int sum;
	
	public Summer(int[] a, int min, int max) {
		this.a = a;
		this.min = min;
		this.max = max;
	}
	
	public int getSum() {
		return sum;
	}
	
	public void run() {
		this.sum = BTMS.sumRange(a, min, max);
	}
}